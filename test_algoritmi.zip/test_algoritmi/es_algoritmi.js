const es1 = (array) => {
    let newArr = [];
    array.forEach((number, index) => {
        let prod = 1;

        array.forEach((numb, i) => {
            if(i !== index) {
                prod *= numb;
            };            
        })

        newArr.push(prod);
    })

    return newArr;
}

// let result1 = es1([1, 2, 3, 4, 5]);
// console.log(result1)


const uniqueNames = (arr1, arr2) => {

    let newArr = [];   

    const pushToArray = (arr) => {
        arr.forEach((name) => {
            if(!newArr.includes(name)) {
                newArr.push(name);
            }
        })
    }

    pushToArray(arr1);
    pushToArray(arr2);

    return newArr;
}

// let result2 = uniqueNames(['gianni', 'maria', 'gino'], ['gianni', 'luigi']);
// console.log(result2);


class TextInput {
    constructor(props) {       

        this.input;
        this.newInput;

        this.setInput(props);
    }

    setInput(input) {
        this.input = input
    }

    add() {
        this.input += this.newInput;
    }

    getInput() {
        return this.input;
    }
}

class NumericInput extends TextInput {
    setInput(input) {
        if(!isNaN(input)) {
            this.input = input;
        }
    }
}

// let text = new TextInput('prova');
// text.newInput = 'g';
// text.add();
// let newText = text.getInput();
// console.log(newText);


const checkLastDigit = (num1, num2) => {
    isNegative1 = num1 < 0 ? true : false;
    isNegative2 = num2 < 0 ? true : false;

    if(!isNegative1 && !isNegative2 && num1 % 10 === num2 % 10) {
        return true;
    } else {
        return false;
    }
}

// const check = checkLastDigit(134, -34);
// console.log(check)




