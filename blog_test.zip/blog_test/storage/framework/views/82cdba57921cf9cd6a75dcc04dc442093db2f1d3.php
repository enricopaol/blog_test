<h1>Welcome</h1>
<h2>Products CRM</h2>
<a href="<?php echo e(route('products.index')); ?>">Tutti i prodotti</a> <br />
<a href="<?php echo e(route('products.create')); ?>">Add new product</a><?php /**PATH C:\Users\usuario\Desktop\lara_test\blog_test\resources\views/home.blade.php ENDPATH**/ ?>