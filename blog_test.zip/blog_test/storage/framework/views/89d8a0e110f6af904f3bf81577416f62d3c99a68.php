<h1>Crea un nuovo prodotto:</h1>
<a href="<?php echo e(route('home')); ?>" style="margin-bottom: 40px; display:block">Torna alla home</a>

<form action="<?php echo e(route('products.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('POST'); ?>

    <div style="margin-bottom: 20px">
        <label for="product_title">Nome prodotto</label>
        <input name="title" id="product_title" type="text" placeholder="Nome prodotto" min="0" max="40">
    </div>

    <div style="margin-bottom: 20px">
        <label for="product_price">Prezzo</label>
        <input name="price" id="product_price" type="number" placeholder="Prezzo" min="0" max="999.99" step="0.01">
    </div>

    <div style="margin-bottom: 20px">
        <label for="publish_date">Data di Pubblicazione</label>
        <input name="publish_date" id="publish_date" type="date" placeholder="Data di pubblicazione">
    </div>

    <div>
        <input type="submit" value="Salva prodotto">
    </div>
</form><?php /**PATH C:\Users\usuario\Desktop\lara_test\blog_test\resources\views/products/create.blade.php ENDPATH**/ ?>