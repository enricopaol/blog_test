<h1>Tutti i prodotti:</h1>
<a href="<?php echo e(route('home')); ?>">Torna alla home</a>

<ul>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <p><?php echo e($product->title); ?></p>
            <p><?php echo e($product->price); ?></p>
            <p><?php echo e($product->publish_date); ?></p>
            <a href="<?php echo e(route('products.show', ['product' => $product->id])); ?>">Vai al dettagio</a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\Users\usuario\Desktop\lara_test\blog_test\resources\views/products/index.blade.php ENDPATH**/ ?>