<h1>Info prodotto</h1>
<a href="<?php echo e(route('products.index')); ?>">Torna alla lista prodotti</a>


<ul>
    <li>
        Nome: <?php echo e($title); ?>

    </li>
    <li>
        Prezzo: <?php echo e($price); ?> €
    </li>
    <li>
        Data di pubblicazione: <?php echo e($publish_date); ?>

    </li>
</ul>

<a href="<?php echo e(route('products.edit', ['product' => $id])); ?>">Modifica prodotto</a><?php /**PATH C:\Users\usuario\Desktop\lara_test\blog_test\resources\views/products/show.blade.php ENDPATH**/ ?>