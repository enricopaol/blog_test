<h1>Welcome</h1>
<h2>Products CRM</h2>
<a href="{{ route('products.index') }}">Tutti i prodotti</a> <br />
<a href="{{ route('products.create') }}">Add new product</a>