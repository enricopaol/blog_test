<h1>Tutti i prodotti:</h1>
<a href="{{ route('home') }}">Torna alla home</a>

<ul>
    @foreach ($products as $product)
        <li>
            <p>{{ $product->title }}</p>
            <p>{{ $product->price }}</p>
            <p>{{ $product->publish_date }}</p>
            <a href="{{ route('products.show', ['product' => $product->id]) }}">Vai al dettagio</a>
        </li>
    @endforeach
</ul>