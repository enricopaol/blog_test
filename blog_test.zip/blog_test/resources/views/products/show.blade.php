<h1>Info prodotto</h1>
<a href="{{ route('products.index') }}">Torna alla lista prodotti</a>


<ul>
    <li>
        Nome: {{ $title }}
    </li>
    <li>
        Prezzo: {{ $price }} €
    </li>
    <li>
        Data di pubblicazione: {{ $publish_date }}
    </li>
</ul>

<a href="{{ route('products.edit', ['product' => $id]) }}">Modifica prodotto</a>