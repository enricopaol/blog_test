<h1>Modifica prodotto: {{ $product->title }}</h1>
<a href="{{ route('products.show', ['product' => $product->id ]) }}" style="margin-bottom: 40px; display:block">Torna alla home</a>


<form action="{{ route('products.update', ['product' => $product->id]) }}" method="post">
    @csrf
    @method('PUT')

    <div style="margin-bottom: 20px">
        <label for="product_title">Nome prodotto</label>
        <input name="title" id="product_title" type="text" placeholder="Nome prodotto" min="0" max="40" value="{{ $product->title }}">
    </div>

    <div style="margin-bottom: 20px">
        <label for="product_price">Prezzo</label>
        <input name="price" id="product_price" type="number" placeholder="Prezzo" min="0" max="999.99" step="0.01" value="{{ $product->price }}">
    </div>

    <div style="margin-bottom: 20px">
        <label for="publish_date">Data di Pubblicazione</label>
        <input name="publish_date" id="publish_date" type="date" placeholder="Data di pubblicazione" value="{{ $product->publish_date }}">
    </div>

    <div>
        <input type="submit" value="Salva modifiche prodotto">
    </div>
</form>